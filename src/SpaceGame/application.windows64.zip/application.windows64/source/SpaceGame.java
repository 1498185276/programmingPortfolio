import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SpaceGame extends PApplet {

// SpaceGame | Dec 2020
// by Mingjing Huang
// TODO: Project Setup


SoundFile laser, explosion;
SpaceShip s1;
ArrayList<Laser> lasers;
ArrayList<Rock> rocks;
ArrayList<Star> stars;
ArrayList<Enemy> enemies;
ArrayList<EnemyLaser> elasers;
ArrayList<PowerUp> pUps;
Timer timer, puTimer, enemyTimer;
int score, pass, weaponCount, laserCount, enemyHealth;
boolean play;

public void setup() {
  
  laser = new SoundFile(this, "ATAT-SideGuns.wav");
  s1 = new SpaceShip();
  lasers = new ArrayList();
  rocks = new ArrayList();
  enemies = new ArrayList();
  stars = new ArrayList();
  elasers = new ArrayList();
  pUps = new ArrayList();
  timer = new Timer(PApplet.parseInt(random(500, 3000)));
  puTimer = new Timer(5000);
  enemyTimer = new Timer(5000);
  score = 0;
  weaponCount = 1;
  laserCount = 0;
  enemyHealth = 100;
  pass = 0;
  play = false;
  timer.start();
  puTimer.start();
}

public void draw() {
  noCursor();
  if (!play) {
    startScreen();
  } else {
    background(0);

    stars.add(new Star(PApplet.parseInt(random(width)), PApplet.parseInt(random(height))));
    for (int i = 0; i < stars.size(); i++) {
      Star star = stars.get(i);
      star.display();
      star.move();
      if (star.reachedBottom()) {
        stars.remove(star);
      }
    }

    if (enemyTimer.isFinished()) {
      enemies.add(new Enemy(0, 80, PApplet.parseInt(random(500, 1500)), enemyHealth));
      enemyTimer.start();
    }

    for (int i = 0; i<enemies.size(); i++) {
      Enemy enemy = enemies.get(i);
      enemy.move();
      enemy.display();
      // enemy and ship intersection
      if (s1.shipIntersect(enemy)) {
        s1.health-=10;
        score+=enemy.healthStart;
        enemies.remove(enemy);
      }
      if (enemy.isFinished()) {
        elasers.add(new EnemyLaser(enemy.x, enemy.y));
        enemy.start();
      }
    }
    
    for (int i = elasers.size()-1; i>=0; i--) {
      EnemyLaser elaser = (EnemyLaser) elasers.get(i);
      elaser.fire();
      elaser.display();
      // Enemy Laser vs. Ship
      if (s1.enemyLaserIntersect(elaser)) {
        s1.health-=elaser.power;
        elasers.remove(elaser);
      }
      if (elaser.reachedBottom()) {
        elasers.remove(elaser);
      }
    }

    if (timer.isFinished()) {
      rocks.add(new Rock(PApplet.parseInt(random(width)), -50));
      timer.start();
    }

    for (int i = 0; i < rocks.size(); i++) {
      Rock rock = rocks.get(i);
      rock.display();
      rock.move();
      // Rock vs Ship Collision
      if (s1.rockIntersection(rock)) {
        s1.health-=rock.health;
        rocks.remove(rock);
        score+=50;
      }
      if (rock.reachedBottom()) {
        pass++;
        rocks.remove(rock);
      }
    }

    for (int i = 0; i < lasers.size(); i++) {
      Laser laser = lasers.get(i);
      laser.display();
      laser.fire();
      // Laser vs. Rock Intersection
      for (int j = 0; j < rocks.size(); j++) {
        Rock rock = rocks.get(j);
        if (rock.laserIntersection(laser)) {
          lasers.remove(laser);
          rock.health-=50;
          if (rock.health<1) {
            rocks.remove(rock);
            score+=rock.health;
          }
        }
      }
      for (int k = 0; k<enemies.size(); k++) {
        Enemy enemy = enemies.get(k);
        if (enemy.laserIntersect(laser)) {
          lasers.remove(laser);
          enemy.health-=20;
          if (enemy.health<1) {
            score+=enemy.healthStart;
            enemies.remove(enemy);
          }
        }
      }
      if (laser.reachedTop()) {
        lasers.remove(laser);
      }
    }

    // PowerUp Distribution
    if (puTimer.isFinished()) {
      pUps.add(new PowerUp(PApplet.parseInt(random(width)), -20));
      puTimer.start();
    }
    // PowerUp rendering and collision detection
    for (int i = 0; i<pUps.size(); i++) {
      PowerUp pu = pUps.get(i);
      pu.move();
      pu.display();
      // PowerUp and ship intersection
      if (s1.puIntersection(pu)) {
        // Apply PowerUp Effects
        if (pu.pu == 0) { // Adds ammo
          s1.ammo+=1000;
        } else if (pu.pu == 1) { //Adds health
          s1.health+=100;
        } else if (pu.pu == 2) { //Adds lasers
          weaponCount++;
        } 
        pUps.remove(pu);
      }
      // dispose of rocks at bottom
      if (pu.reachedBottom()) {
        pUps.remove(pu);
      }
    }

    s1.display(mouseX, mouseY);

    infoPanel();
    if (s1.health<1 || pass>10) {
      play = false;
      gameOver();
    }
  }
}

public void mousePressed() {
  if (play) {
    laser.play();
  }

  if (s1.ammo > 0) {
    lasers.add(new Laser(s1.x, s1.y));
  }
  s1.ammo -- ;

  if (s1.ammo>0) {
    if (weaponCount == 1) {
      lasers.add(new Laser(s1.x, s1.y));
      laserCount++;
      s1.ammo--;
    } else if (weaponCount == 2) {
      lasers.add(new Laser(s1.x-20, s1.y));
      lasers.add(new Laser(s1.x+20, s1.y));
      laserCount++;
      s1.ammo-=2;
    } else if (weaponCount == 3) {
      lasers.add(new Laser(s1.x, s1.y));
      lasers.add(new Laser(s1.x-20, s1.y));
      lasers.add(new Laser(s1.x+20, s1.y));
      laserCount++;
      s1.ammo-=3;
    } else if (weaponCount == 4) {
      lasers.add(new Laser(s1.x-20, s1.y));
      lasers.add(new Laser(s1.x+20, s1.y));
      lasers.add(new Laser(s1.x-40, s1.y));
      lasers.add(new Laser(s1.x+40, s1.y));
      laserCount++;
      s1.ammo-=4;
    } else if (weaponCount == 5) {
      lasers.add(new Laser(s1.x, s1.y));
      lasers.add(new Laser(s1.x-20, s1.y));
      lasers.add(new Laser(s1.x+20, s1.y));
      lasers.add(new Laser(s1.x-40, s1.y));
      lasers.add(new Laser(s1.x+40, s1.y));
      laserCount++;
      s1.ammo-=5;
    } else if (weaponCount == 6) {
      lasers.add(new Laser(s1.x-20, s1.y));
      lasers.add(new Laser(s1.x+20, s1.y));
      lasers.add(new Laser(s1.x-40, s1.y));
      lasers.add(new Laser(s1.x+40, s1.y));
      lasers.add(new Laser(s1.x-60, s1.y));
      lasers.add(new Laser(s1.x+60, s1.y));
      laserCount++;
      s1.ammo-=6;
    } else if (weaponCount >= 7) {
      lasers.add(new Laser(s1.x, s1.y));
      lasers.add(new Laser(s1.x-20, s1.y));
      lasers.add(new Laser(s1.x+20, s1.y));
      lasers.add(new Laser(s1.x-40, s1.y));
      lasers.add(new Laser(s1.x+40, s1.y));
      lasers.add(new Laser(s1.x-60, s1.y));
      lasers.add(new Laser(s1.x+60, s1.y));
      laserCount++;
      s1.ammo-=7;
    }
  }
}

public void startScreen() {
  background(0);
  textAlign(CENTER);
  text("Welcome!", width/2, height/2);
  text("Click to Continue...", width/2, height/2+20);
  if (mousePressed) {
    play = true;
  }
}

public void infoPanel() {
  fill(128, 128);
  rectMode(CORNER);
  rect(0, height-50, width, 50);
  fill(255, 128);
  text("Health:" + s1.health, 50, height-20);
  text("Lives:" + s1.lives, 150, height-20);
  text("Pass:" + pass, 420, height-20);
  text("Ammo:" + s1.ammo, 220, height-20);
  text("Level:", 300, height-20);
  text("Score:" + score, 350, height-20);
}

public void gameOver() {
  background(0);
  textAlign(CENTER);
  fill(222);
  text("Game Over!", width/2, height/2);
  text("Final Score:" + score, width/2, height/2+20);
  noLoop();
}
class EnemyLaser {
  int x, y, speed, r, power; 
  int c;

  EnemyLaser(int x, int y) {
    r = 4; 
    power = PApplet.parseInt(random(10,100));
    this.x = x; 
    this.y = y; 
    speed = PApplet.parseInt(random(5, 22));    
    c = color(0, 0, 255);
  }

  public void fire() {
    y += speed;
  }

  public boolean reachedBottom() {
    if (y > height) { 
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    fill(c);
    noStroke();
    rect(x, y, r, 8);
  }
}
class Enemy {
  int r, health, x, y, speed, healthStart;
  boolean right;
  int savedTime; 
  int totalTime;

  // constructor
  Enemy(int x, int y, int t, int health) {
    healthStart = health;
    r = 25;
    this.x = x;
    this.y = y;
    this.health = health;
    speed = 5;
    this.totalTime = t;
  }

  // member methods
  public void display() {
    fill(0xffEBF29D);
    triangle(x, y, x-20, y+20, x+20, y+20);
    fill(0xffD1513D);
    circle(x, y+10, 8);
    textSize(10);
    textAlign(CENTER);
    text(health, x, y);
  }

  public void move() {
    x += speed;
    if (x >= width|| x <= 0) {
      speed *= -1;
      y+=50;
    }
  }

  public boolean laserIntersect(Laser laser) {
    // Calculate distance
    float distance = dist(x, y, laser.x, laser.y); 

    // Compare distance to sum of radii
    if (distance < r + laser.rad) { 
      return true;
    } else {
      return false;
    }
  }

  public void start() {
    savedTime = millis();
  }


  public boolean isFinished() { 
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
class Laser{
  // member variables
  int x,y,speed,rad;
  int c;
  
  // constructor
  Laser(int x, int y){
    this.x = x;
    this.y = y;
    speed = 6;
    c = 0xffB9504D;
    rad = 4;
  }
  
  // member methods
  public void display(){
    fill(c);
    noStroke();
    rectMode(CENTER);
    rect(x,y,rad,rad*2);
  }
  
  public void fire(){
    y-=speed;
  }
  
  public boolean reachedTop(){
    if(y<-3){
      return true;
    } else {
      return false;
    }
  }
}
class PowerUp {
  // member variables
  int x, y, r, speed, pu;
  String[] puInfo = {"Ammo", "Health", "Lasers"};

  // constructor
  PowerUp(int x, int y) {
    this.x = x;
    this.y = y;
    r = 60;
    pu = PApplet.parseInt(random(3));
    speed = PApplet.parseInt(random(2, 4));
  }

  public void move() {
    y += speed;
  }

  public boolean reachedBottom() {
    if (y > height + r*4) { 
      return true;
    } else {
      return false;
    }
  }

  // member methods
  public void display() {
    noStroke();
    switch(pu) {
    case 0: // Ammo
      fill(255, 0, 0);
      ellipse(x, y, r, r);
      fill(255);
      textSize(9);
      textAlign(CENTER);
      text(puInfo[0], x, y);
      break;
    case 1: // Health
      fill(0, 255, 0);
      ellipse(x, y, r, r);
      fill(255);
      textSize(9);
      textAlign(CENTER);
      text(puInfo[1], x, y);
      break;
    case 2: // Lasers
      fill(0, 0, 255);
      ellipse(x, y, r, r);
      fill(255);
      textSize(9);
      textAlign(CENTER);
      text(puInfo[2], x, y);
      break;
    }
  }
}
class Rock{
  // member variables
  int x,y,rad,health,speed;
  char displayMode;
  PImage rock;
  
  // constructor
  Rock(int x, int y){
    this.x = x;
    this.y = y;
    rad = 25;
    health = 25;
    speed = PApplet.parseInt(random(1,8));
    displayMode = '1';
    rock = loadImage("rock.png");
  }
  
  // Rock vs Laser Collision
  public boolean laserIntersection(Laser laser){
    float distance = dist(x,y,laser.x,laser.y);
    if(distance < rad + laser.rad){
      return true;
    } else {
      return false;
    }
  }
  
  public boolean reachedBottom(){
    if(y>height){
      return true;
    } else {
      return false;
    }
  }
  
  public void move(){
    y += speed;
  }
  
  // member methods
  public void display(){
    //ellipse(x,y,dia,dia);
    image(rock,x,y);
  }
  
  public void collide(){
  
  }
}
class SpaceShip {
  // member variables
  int x, y, health, ammo, lives, rad;
  char displayMode;
  PImage spaceship;

  // constructor
  SpaceShip() {
    x = 0;
    y = 0;
    health = 100;
    ammo = 1000;
    lives = 3;
    displayMode = '1';
    spaceship = loadImage("spaceship.png");
    rad = 25;
  }

  // member methods
  public void display(int x, int y) {
    this.x = x;
    this.y = y;
    image(spaceship, x, y);
  }

  // Rock vs Ship Collision
  public boolean rockIntersection(Rock rock) {
    float distance = dist(x, y, rock.x, rock.y);
    if (distance < rad + rock.rad) {
      return true;
    } else {
      return false;
    }
  }

  public boolean puIntersection(PowerUp pu) {
    // Calculate distance
    float distance = dist(x, y, pu.x, pu.y); 

    // Compare distance to sum of radii
    if (distance < rad + pu.r) { 
      return true;
    } else {
      return false;
    }
  }

  public boolean shipIntersect(Enemy enemy) {
    // Calculate distance
    float distance = dist(x, y, enemy.x, enemy.y); 

    // Compare distance to sum of radii
    if (distance < rad + enemy.r) { 
      return true;
    } else {
      return false;
    }
  }

  public boolean enemyLaserIntersect(EnemyLaser elaser) {
  // Calculate distance
    float distance = dist(x, y, elaser.x, elaser.y); 

  // Compare distance to sum of radii
    if (distance < rad + elaser.r) { 
      return true;
    } else {
      return false;
    }
  }
}
class Star{
  // member variables
  int x,y,speed,dia;
  int c;
  
  // constructor
  Star(int x, int y){
    this.x = x;
    this.y = y;
    speed = PApplet.parseInt(random(1,10));
    dia = PApplet.parseInt(random(1,4));
    c = color(random(190,255));
  }
  
   public boolean reachedBottom(){
    if(y>height){
      return true;
    } else {
      return false;
    }
  }
  
  public void move(){
    y += speed;
  }
  
  // member methods
  public void display(){
    fill(c);
    noStroke();
    ellipse(x,y,dia,dia);
  }
}
// Example 10-5: Object-oriented timer
// by Daniel Shiffman

class Timer {

  int savedTime; // When Timer started
  int totalTime; // How long Timer should last

  Timer(int tempTotalTime) {
    totalTime = tempTotalTime;
  }

  // Starting the timer
  public void start() {
    // When the timer starts it stores the current time in milliseconds.
    savedTime = millis();
  }

  // The function isFinished() returns true if 5,000 ms have passed. 
  // The work of the timer is farmed out to this method.
  public boolean isFinished() { 
    // Check how much time has passed
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
  public void settings() {  size(700, 700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SpaceGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
